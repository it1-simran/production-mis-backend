const mongoose = require("mongoose");
const { Schema } = mongoose;

const PlaningLogSchema = new Schema({
  action: {
    type: String,
    required: true,
    enum: ["CREATE", "UPDATE", "DELETE", "CLONE","SHIFT_CHANGE","HOLD", "ASSIGN","ASSIGN_JIG"],
  },
  planId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Planning",
    required: true,
  },
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
    required: true,
  },
  description: {
    type: String,
    default: "",
  },
  timestamp: {
    type: Date,
    default: Date.now,
  },
});

module.exports = mongoose.model("planingLog", PlaningLogSchema);
