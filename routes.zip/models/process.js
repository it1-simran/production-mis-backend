const mongoose = require("mongoose");

const processSchema = new mongoose.Schema({
  name: { type: String, required: true },
  selectedProduct: { type: mongoose.Schema.Types.ObjectId, ref: 'products', required: true },
  orderConfirmationNo: { type: String, required: true },
  processID: { type: String, required: true },
  quantity: { type: String, required: true },
  descripition: { type: String, required: true },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now },
});

// Creating the model from schema
const Process = mongoose.model("process", processSchema);

module.exports = Process;
