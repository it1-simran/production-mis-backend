const mongoose = require("mongoose");

const moment = require("moment");
const PlaningAndSchedulingModel = require("../models/planingAndSchedulingModel");
const PlaningLogsModel = require("../models/PlaningLogs");
const RoomPlanModel = require("../models/roomPlan");
const assignedOperatorsToPlanModel = require("../models/assignOperatorToPlan");
const ShiftModel = require("../models/shiftManagement");
module.exports = {
  create: async (req, res) => {
    try {
      const formatDateForMongoose = (dateString) => {
        const [day, month, yearAndTime] = dateString.split("/");
        const [year, time] = yearAndTime.split(" ");
        const [hours, minutes, seconds] = time.split(":");
        return new Date(`20${year}`, month - 1, day, hours, minutes, seconds);
      };
      const data = req?.body;
      const assignOperator = JSON.parse(data?.assignedOperators);
      const keys = Object.keys(assignOperator);
      const roomAndSeatNumber = keys[0].split("-");
      data.ProcessShiftMappings = JSON.parse(data?.ProcessShiftMappings);
      data.startDate = formatDateForMongoose(data?.startDate);
      data.estimatedEndDate = formatDateForMongoose(data?.estimatedEndDate);
      const newPlanAndScheduling = new PlaningAndSchedulingModel(data);
      await newPlanAndScheduling.save();
      const data1 = {
        planId: newPlanAndScheduling?._id,
        userId: assignOperator[keys[0]][0]?._id,
        roomName: data?.selectedRoom,
        seatDetails: {
          rowNumber: roomAndSeatNumber[0],
          seatNumber: roomAndSeatNumber[1],
        },
        ProcessShiftMappings: data?.ProcessShiftMappings,
        startDate: data?.startDate,
        estimatedEndDate: data?.estimatedEndDate,
      };
      const assignOperators = new assignedOperatorsToPlanModel(data1);
      await assignOperators.save();
      return res.status(200).json({
        status: 200,
        message: "Planing And Scheduling Created Successfully!!",
        newPlanAndScheduling,
      });
    } catch (error) {
      return res.status(500).json({ status: 500, error: error.message });
    }
  },
  update: async (req, res) => {
    try {
      const formatDateForMongoose = (dateString) => {
        const [day, month, yearAndTime] = dateString.split("/");
        const [year, time] = yearAndTime.split(" ");
        const [hours, minutes, seconds] = time.split(":");

        return new Date(`20${year}`, month - 1, day, hours, minutes, seconds);
      };
      const id = req.params.id;
      const updatedData = req.body;
      updatedData.ProcessShiftMappings = JSON.parse(
        updatedData.ProcessShiftMappings
      );
      updatedData.startDate = formatDateForMongoose(updatedData.startDate);
      updatedData.estimatedEndDate = formatDateForMongoose(
        updatedData.estimatedEndDate
      );
      const updatedPlaningAndScheduling =
        await PlaningAndSchedulingModel.findByIdAndUpdate(id, updatedData, {
          new: true,
          runValidators: true,
        });

      if (!updatedPlaningAndScheduling) {
        return res
          .status(404)
          .json({ message: "Planing and Scheduling not found" });
      }

      return res.status(200).json({
        status: 200,
        message: "Planing and Scheduling Updated Successfully!!",
        shift: updatedPlaningAndScheduling,
      });
    } catch (error) {
      return res.status(500).json({ status: 500, error: error.message });
    }
  },
  view: async (req, res) => {
    try {
      let plans = await PlaningAndSchedulingModel.find();
      return res.status(200).json({
        status: 200,
        message: "Planning and scheduling fetched successfully!",
        plans,
      });
    } catch (error) {
      return res.status(500).json({ status: 500, error: error.message });
    }
  },
  checkAvailability: async (req, res) => {
    try {
      const { roomId, shiftId, startDate, expectedEndDate, shiftDataChange } =
        req.body;
      let changedData = JSON.parse(shiftDataChange);
      console.log("shiftId ==>", shiftId);
      if (!roomId || !shiftId || !startDate || !expectedEndDate) {
        return res.status(400).json({
          error:
            "Room ID, Shift ID, Start Date, and Expected End Date are required.",
        });
      }
      const parsedStartDate = moment.utc(startDate, "DD/MM/YY HH:mm:ss", true);
      const parsedEndDate = moment.utc(
        expectedEndDate,
        "DD/MM/YY HH:mm:ss",
        true
      );
      if (!parsedStartDate.isValid() || !parsedEndDate.isValid()) {
        return res.status(400).json({
          status: 400,
          error: "Invalid date format. Expected format: DD/MM/YY HH:mm:ss.",
        });
      }
      if (parsedStartDate.isAfter(parsedEndDate)) {
        return res.status(400).json({
          status: 400,
          error: "Start Date must be earlier than Expected End Date.",
        });
      }
      const shift = await ShiftModel.findById(shiftId);
      if (!shift) {
        return res.status(404).json({
          status: 404,
          error: "Shift not found.",
        });
      }
      let shiftStartTime, shiftEndTime;
      shiftStartTime = moment(shift.startTime, "HH:mm");
      shiftEndTime = moment(shift.endTime, "HH:mm");
      const query = {
        selectedRoom: new mongoose.Types.ObjectId(roomId),
        $or: [
          {
            startDate: {
              $gte: parsedStartDate.toISOString(),
              $lte: parsedEndDate.toISOString(),
            },
          },
          {
            estimatedEndDate: {
              $gte: parsedStartDate.toISOString(),
              $lte: parsedEndDate.toISOString(),
            },
          },
          {
            $and: [
              { startDate: { $lte: parsedStartDate.toISOString() } },
              { estimatedEndDate: { $gte: parsedEndDate.toISOString() } },
            ],
          },
        ],
        isDrafted: 0,
      };
      const plans = await PlaningAndSchedulingModel.find(query);

      const filteredPlans = plans.filter((plan) => {
        const { startTime, endTime } = plan.ProcessShiftMappings || {};
        if (!startTime || !endTime) return false;
        const planStartTime = moment(startTime, "HH:mm");
        const planEndTime = moment(endTime, "HH:mm");
        return (
          shiftStartTime.isSameOrBefore(planEndTime.startOf("minute")) &&
          shiftEndTime.isSameOrAfter(planStartTime.startOf("minute"))
        );
      });
      if (filteredPlans.length === 0) {
        return res.status(404).json({
          status: 404,
          error:
            "No available seats for the given room, shift, and date range.",
        });
      }
      return res.status(200).json({
        status: 200,
        message: "Available seats fetched successfully!",
        plans: filteredPlans,
      });
    } catch (error) {
      console.error("Error in checkAvailability: ", error.message);
      return res.status(500).json({
        status: 500,
        error: "Internal server error.",
        details: error.message,
      });
    }
  },
  checkAvailabilityFromCurrentDate: async (req, res) => {
    try {
      const { roomId, shiftId } = req.body;
      if (!roomId || !shiftId) {
        return res.status(400).json({
          status: 400,
          error: "Room ID and Shift ID are required.",
        });
      }
      const currentDate = moment.utc().startOf("day");
      const startISO = currentDate.toISOString();
      const endDate = moment.utc().add(30, "days").toISOString();
      const roomPlan = await RoomPlanModel.findById(roomId);
      if (!roomPlan) {
        return res.status(404).json({
          status: 404,
          error: "Room not found.",
        });
      }
      const totalSeatsInRoom = roomPlan.lines.reduce(
        (totalSeats, line) => totalSeats + line.seats.length,
        0
      );
      const plans = await PlaningAndSchedulingModel.find({
        selectedRoom: new mongoose.Types.ObjectId(roomId),
        selectedShift: new mongoose.Types.ObjectId(shiftId),
        isDrafted: 0,
      });
      const seatAvailability = {};
      plans.forEach((plan) => {
        const planStartDate = moment(plan.startDate).startOf("day");
        const planEndDate = moment(plan.estimatedEndDate).endOf("day");
        let currentDateInRange = planStartDate.clone();
        while (currentDateInRange.isSameOrBefore(planEndDate)) {
          const dateString = currentDateInRange.toISOString().split("T")[0];
          if (!seatAvailability[dateString]) {
            seatAvailability[dateString] = totalSeatsInRoom;
          }
          const assignedStages = Object.keys(
            JSON.parse(plan?.assignedStages || "{}")
          ).length;
          seatAvailability[dateString] -= assignedStages;
          currentDateInRange.add(1, "days");
        }
      });
      const dates = Object.keys(seatAvailability);
      return res.status(200).json({
        status: 200,
        message: "Planning and scheduling fetched successfully!",
        seatAvailability,
      });
    } catch (error) {
      console.error(
        "Error in checkAvailabilityFromCurrentDate: ",
        error.message
      );
      return res.status(500).json({
        status: 500,
        error: "Internal server error.",
        details: error.message,
      });
    }
  },
  delete: async (req, res) => {
    try {
      const planId = req.params.id;
      const planingAndScheduling =
        await PlaningAndSchedulingModel.findByIdAndDelete(planId);
      await PlaningLogsModel.deleteMany({ planId });
      if (!planingAndScheduling) {
        return res
          .status(404)
          .json({ message: "Planing & Scheduling not found" });
      }
      res.status(200).json({
        message: "Planing & Scheduling deleted successfully",
        planingAndScheduling,
      });
    } catch (error) {
      return res.status(500).json({ status: 500, error: error.message });
    }
  },
  deletePlaningMultiple: async (req, res) => {
    try {
      const ids = req.body.deleteIds;
      if (!Array.isArray(ids) || ids.length === 0) {
        return res.status(400).json({
          message: "Invalid request, ids must be an array of strings",
        });
      }
      const objectIds = ids.map((id) => {
        if (mongoose.Types.ObjectId.isValid(id)) {
          return new mongoose.Types.ObjectId(id);
        } else {
          throw new Error(`Invalid ObjectId: ${id}`);
        }
      });
      const result = await PlaningAndSchedulingModel.deleteMany({
        _id: { $in: objectIds },
      });
      if (result.deletedCount === 0) {
        return res.status(404).json({ message: "No items found to delete" });
      }
      return res.status(200).json({
        message: `${result.deletedCount} item(s) deleted successfully`,
      });
    } catch (error) {
      if (error.message.startsWith("Invalid ObjectId")) {
        return res.status(400).json({ message: error.message });
      }
      console.error("Error deleting multiple items:", error);
      return res
        .status(500)
        .json({ message: "Server error", error: error.message });
    }
  },
  getPlaningAnDschedulingByID: async (req, res) => {
    try {
      const id = req.params.id;
      const PlaningAndScheduling = await PlaningAndSchedulingModel.findById(id);
      if (!PlaningAndScheduling) {
        return res.status(404).json({ error: "Product not found" });
      }
      return res.status(200).json(PlaningAndScheduling);
    } catch (error) {
      console.error("Error Fetching Planing And Scheduling :", error);
      return res
        .status(500)
        .json({ message: "Server error", error: error.message });
    }
  },
  fetchAllPlaningModel: async (req, res) => {
    try {
      const PlaningAndScheduling = await PlaningAndSchedulingModel.find();
      return res.status(200).json({
        status: 200,
        message: "Planing Model Fetched Successfully!!",
        PlaningAndScheduling,
      });
    } catch (error) {
      return res.status(500).json({ staus: 500, error: error.message });
    }
  },
  planingAndSchedulingLogs: async (req, res) => {
    try {
      const data = req?.body;
      const planingLogs = new PlaningLogsModel(data);
      await planingLogs.save();
      return res.status(200).json({
        status: 200,
        message: "Planing Logs Created Successfully!!",
        planingLogs,
      });
    } catch (error) {
      return res.status(500).json({ staus: 500, error: error.message });
    }
  },
  getLogsByPlanId: async (req, res) => {
    try {
      const id = req.params.id;
      const PlaningAndSchedulingLogs = await PlaningLogsModel.find({
        planId: id,
      });
      if (!PlaningAndSchedulingLogs) {
        return res.status(404).json({ error: "Product not found" });
      }
      return res.status(200).json(PlaningAndSchedulingLogs);
    } catch (error) {
      return res.status(500).json({ staus: 500, error: error.message });
    }
  },
};
