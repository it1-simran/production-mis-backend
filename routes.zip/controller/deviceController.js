const deviceModel = require("../models/device");
const deviceTestRecords = require("../models/deviceTestModel");
const mongoose = require("mongoose");

module.exports = {
  create: async (req, res) => {
    try {
      const data = req.body;
      const productType = data.selectedProduct;
      const devices = JSON.parse(data.devices);
      const currentStage = req.body.currentStage;

      const savedDevices = [];

      for (const value of devices) {
        const device = new deviceModel({
          productType,
          serialNo: value[0],
          currentStage,
        });
        const savedDevice = await device.save();
        savedDevices.push(savedDevice);
      }

      return res.status(200).json({
        status: 200,
        message: "Devices added successfully",
        data: savedDevices,
      });
    } catch (error) {
      return res.status(500).json({ status: 500, error: error.message });
    }
  },
  getDeviceByProductId: async (req, res) => {
    try {
      const id = req.params.id;
      if (!mongoose.Types.ObjectId.isValid(id)) {
        return res.status(400).json({
          status: 400,
          error: "Invalid Product ID",
        });
      }
      const devices = await deviceModel.find({ productType: id });
      if (devices.length === 0) {
        return res.status(404).json({
          status: 404,
          message: "No devices found for the given Product ID",
        });
      }
      return res.status(200).json({
        status: 200,
        message: "Devices retrieved successfully",
        data: devices,
      });
    } catch (error) {
      return res.status(500).json({
        status: 500,
        error: error.message,
      });
    }
  },
  createDeviceTestEntry: async (req, res) => {
    try {
      const data = req.body;
      const deviceTestRecord = new deviceTestRecords(data);
      const savedDeviceTestRecord = await deviceTestRecord.save();
      return res.status(200).json({
        status: 200,
        message: "Devices Test Entry added successfully",
        data: savedDeviceTestRecord,
      });
    } catch (error) {
      return res.status(500).json({
        status: 500,
        error: error.message,
      });
    }
  },
  getDeviceTestEntryByOperatorId: async (req, res) => {
    try {
      const id = req.params.id;
      const startOfDay = new Date();
      startOfDay.setHours(0, 0, 0, 0);
      const endOfDay = new Date();
      endOfDay.setHours(23, 59, 59, 999);
      const deviceTestRecord = await deviceTestRecords.find({
        operatorId: id,
        createdAt: {
          $gte: startOfDay,
          $lt: endOfDay,
        },
      });
      if (deviceTestRecord.length === 0) {
        return res.status(404).json({
          status: 404,
          message: "No device records found for the given Operator ID on the current date",
        });
      }
      return res.status(200).json({
        status: 200,
        message: "Device records retrieved successfully",
        data: deviceTestRecord,
      });
    } catch (error) {
      return res.status(500).json({
        status: 500,
        error: error.message,
      });
    }
  },

  getDeviceTestHistoryByDeviceId: async (req, res) => {
    try { 
      let id = req.params.deviceId;
      let deviceTestHistory = await deviceTestRecords.find({ deviceId: id });
      if (deviceTestHistory.length === 0) {
        return res.status(200).json({
          status: 200,
          message: "No devices record history found for the given Product ID",
          data: [],
        });
      }
      return res.status(200).json({
        status: 200,
        message: "Devices Record retrieved successfully",
        data: deviceTestHistory,
      });
    } catch (error) {
      return res.status(500).json({
        status: 500,
        error: error.message,
      });
    }
  },
  updateStageByDeviceId: async (req, res) => {
    try {
      let deviceId = req.params.deviceId;
      let updates = req.body;
      const updatedDevice = await deviceModel.findByIdAndUpdate(
        deviceId,
        { $set: updates },
        { new: true, runValidators: true } // Return updated document and validate inputs
      );
      if (!updatedDevice) {
        return res.status(404).json({ message: "Device not found" });
      }
      res.status(200).json({
        status: 200,
        message: "Device updated successfully",
        updatedDevice,
      });
    } catch (error) {
      return res.status(500).json({
        status: 500,
        error: error.message,
      });
    }
  },
  getOverallProcessByOperatorId: async (req, res) => {
    try {
      const { planId, operatorId } = req.params;
      const devices = await deviceTestRecords.find({ planId, operatorId });
      if (devices.length === 0) {
        return res.status(404).json({
          status: 404,
          message: "No devices found for the given plan and operator.",
        });
      }
      res.status(200).json({
        status: 200,
        message: "Overall process retrieved successfully!",
        data: devices,
      });
    } catch (error) {
      return res.status(500).json({
        status: 500,
        message: "An error occurred while retrieving the process.",
        error: error.message,
      });
    }
  },
};
