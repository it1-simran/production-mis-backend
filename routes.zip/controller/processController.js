const mongoose = require("mongoose");
const ProcessModel = require("../models/Process");
module.exports = {
  create: async (req, res) => {
    try {
      const data = req?.body;
      const newProcess = new ProcessModel(data);
      await newProcess.save();
      return res.status(200).json({
        status: 200,
        message: "Process Created Successfully!!",
        newProcess,
      });
    } catch (error) {
      return res.status(500).json({ status: 500, error: error.message });
    }
  },
  view: async (req, res) => {
    try {
      const Processes = await ProcessModel.find();
      return res.status(200).json({
        status: 200,
        message: "Process Fetched Successfully!!",
        Processes,
      });
    } catch (error) {
      return res.status(500).json({ staus: 500, error: error.message });
    }
  },
  delete: async (req, res) => {
    try {
      const Process = await ProcessModel.findByIdAndDelete(req.params.id);
      if (!Process) {
        return res.status(404).json({ message: "Process not found" });
      }
      res.status(200).json({ message: "Process Deleted Successfully!!", Process });
    } catch (error) {
      return res.status(500).json({ status: 500, error: error.message });
    }
  },
  deleteProcessMultiple:  async (req,res)=> {
    try {
        const ids = req.body.deleteIds;
        if (!Array.isArray(ids) || ids.length === 0) {
          return res
            .status(400)
            .json({
              message: "Invalid request, ids must be an array of strings",
            });
        }
        const objectIds = ids.map((id) => {
          if (mongoose.Types.ObjectId.isValid(id)) {
            return new mongoose.Types.ObjectId(id);
          } else {
            throw new Error(`Invalid ObjectId: ${id}`);
          }
        });
  
        const result = await ProcessModel.deleteMany({ _id: { $in: objectIds } });
        if (result.deletedCount === 0) {
          return res.status(404).json({ message: "No items found to delete" });
        }
        return res
          .status(200)
          .json({
            message: `${result.deletedCount} Process(es) deleted successfully`,
          });
    } catch (error) {
        return res.status(500).json({status:500, error: error.message});
    }
  },
  getProcessByID : async (req,res) =>{
    try {
        const id = req.params.id;
        const process = await ProcessModel.findById(id);
        if (!process) {
          return res.status(404).json({ error: "Process not found" });
        }
        return res.status(200).json(process);
    } catch (error) {
        return res.status(500).json({status:500,error:error.message});
    }
  },
  update : async (req,res) =>{
    try {
        const id = req.params.id;
        const updatedData = req.body
    
        const updatedProcess = await ProcessModel.findByIdAndUpdate(id, updatedData, { 
          new: true,
          runValidators: true,
        });
    
        if (!updatedProcess) {
          return res.status(404).json({ message: 'Process not found' });
        }
  
        return res.status(200).json({
          status: 200,
          message: 'Process updated successfully!!',
          shift: updatedProcess,
        });
    } catch (error) {
        return res.status(500).json({status:500,error:error.message});
    }
  }
};
