const mongoose = require("mongoose");
const moment = require("moment");
const assignedOperatorsToPlanModel = require("../models/assignOperatorToPlan");
const planningAndSchedulingModel = require("../models/planingAndSchedulingModel");
module.exports = {
  create: async (req, res) => {
    try {
      const data = req?.body;
      const assignedOperatorsToPlan = new assignedOperatorsToPlanModel(data);
      await assignedOperatorsToPlan.save();
      return res.status(200).json({
        status: 200,
        message: "Operator Assigned Successfully!!",
        newPlanAndScheduling,
      });
    } catch (error) {
      return res.status(500).json({ status: 500, error: error.message });
    }
  },
  getTaskByUserID: async (req, res) => {
    try {
      const userId = req.params.id;
      const currentDate = moment.utc().startOf("day").toISOString();
      const task = await assignedOperatorsToPlanModel.aggregate([
        {
          $match: { userId: new mongoose.Types.ObjectId(userId) },
        },
        {
          $lookup: {
            from: "planingandschedulings",
            localField: "planId",
            foreignField: "_id",
            as: "planDetails",
          },
        },
        {
          $unwind: "$planDetails",
        },
        {
          $lookup: {
            from: "roomplans",
            localField: "roomName",
            foreignField: "_id",
            as: "roomDetails",
          },
        },
        {
          $unwind: "$roomDetails",
        },
        {
          $project: {
            userId: 1,
            planId: 1,
            seatDetails: 1,
            ProcessShiftMappings: 1,
            roomName: 1,
            "roomDetails.floorName": 1,
            "planDetails.processName": 1,
            "planDetails.assignedStages": 1, 
            "planDetails.startDate": 1,
            "planDetails.estimatedEndDate": 1,
            "planDetails.roomName": 1,
            "planDetails.seatDetails": 1,
          },
        },
      ]);
      if (!task.length) {
        return res.status(404).json({
          status: 404,
          message: "No tasks found for the given user and date.",
        });
      }
      return res.status(200).json({
        status: 200,
        message: "Task Retrieved Successfully!!",
        task,
      });
    } catch (error) {
      return res.status(500).json({ status: 500, error: error.message });
    }
  },

  // getTaskByUserID: async (req, res) => {
  //   try {
  //     const userId = req.params.id;
  //     const currentDate = moment.utc().startOf("day");
  //     const currentDateISO = currentDate.toISOString();
  //     const task = await assignedOperatorsToPlanModel.aggregate([
  //       {
  //         $match: { userId: new mongoose.Types.ObjectId(userId) },
  //       },
  //       {
  //         $lookup: {
  //           from: "planingandschedulings",
  //           localField: "planId",
  //           foreignField: "_id",
  //           as: "planDetails",
  //         },
  //       },
  //       {
  //         $unwind: "$planDetails",
  //       },
  //       {
  //         $lookup: {
  //           from: "roomplans",
  //           localField: "roomName",
  //           foreignField: "_id",
  //           as: "roomDetails",
  //         },
  //       },
  //       {
  //         $unwind: "$roomDetails",
  //       },
  //       {
  //         $match: {
  //           $expr: {
  //             $and: [
  //               {currentDateISO , $gte: [{ $toDate: "startDate" }]},
  //               {currentDateISO , $lte: [{ $toDate: "estimatedEndDate" }]},
  //             ],
  //           },
  //         },
  //       },
  //       {
  //         $project: {
  //           userId: 1,
  //           planId: 1,
  //           seatDetails: 1,
  //           ProcessShiftMappings: 1,
  //           roomName: 1,
  //           "roomDetails.floorName": 1,
  //           "planDetails.processName": 1,
  //           "planDetails.startDate": 1,
  //           "planDetails.estimatedEndDate": 1,
  //           "planDetails.roomName": 1,
  //           "planDetails.seatDetails": 1,
  //         },
  //       },
  //     ]);

  //     return res.status(200).json({
  //       status: 200,
  //       message: "Task Retrieved Successfully!!",
  //       task,
  //     });
  //   } catch (error) {
  //     return res.status(500).json({ status: 500, error: error.message });
  //   }
  // },

  // getTaskByUserID: async (req, res) => {
  //   try {
  //     const userId = req.params.id;
  //     const currentDate = moment.utc().startOf("day");
  //     const task = await assignedOperatorsToPlanModel.aggregate([
  //       {
  //         $match: { userId: new mongoose.Types.ObjectId(userId) },
  //       },
  //       {
  //         $lookup: {
  //           from: "planingandschedulings",
  //           localField: "planId",
  //           foreignField: "_id",
  //           as: "planDetails",
  //         },
  //       },
  //       {
  //         $unwind: "$planDetails",
  //       },
  //       {
  //         $lookup: {
  //           from: "roomplans",
  //           localField: "roomName",
  //           foreignField: "_id",
  //           as: "roomDetails",
  //         },
  //       },
  //       {
  //         $unwind: "$roomDetails",
  //       },
  //       // {
  //       //   $match: {
  //       //     $expr: {
  //       //       $and: [
  //       //         { $gte: [currentDate, "$planDetails.startDate"] },
  //       //         { $lte: [currentDate, "$planDetails.estimatedEndDate"] },
  //       //       ],
  //       //     },
  //       //   },
  //       // },
  //       {
  //         $project: {
  //           userId: 1,
  //           planId: 1,
  //           seatDetails: 1,
  //           ProcessShiftMappings: 1,
  //           roomName: 1,
  //           "roomDetails.floorName": 1,
  //           "planDetails.processName": 1,
  //           "planDetails.startDate": 1,
  //           "planDetails.estimatedEndDate": 1,
  //           "planDetails.roomName": 1,
  //           "planDetails.seatDetails": 1,
  //         },
  //       },
  //     ]);

  //     return res.status(200).json({
  //       status: 200,
  //       message: "Task Retrieved Successfully!!",
  //       task,
  //     });
  //   } catch (error) {
  //     return res.status(500).json({ status: 500, error: error.message });
  //   }
  // },
};
